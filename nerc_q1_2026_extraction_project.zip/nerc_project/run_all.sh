#!/bin/sh
# Re-runs the whole pipeline from the untouched raw PDF. Run from the project root.
set -e
sha256sum -c data/raw/SHA256SUMS.txt
for s in 01_inventory 02_extract 03_clean 04_validate 05_crosscheck 05b_record_visual_check 06_replicate 07_make_chart 08_engine_checks; do
  echo "=== $s ==="; python3 scripts/$s.py > logs/$s.log 2>&1 && tail -n 3 logs/$s.log
done
