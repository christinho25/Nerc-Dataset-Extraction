"""Step 2: extract DisCo performance tables (Tables 4-9) from the raw PDF.

Why not pdfplumber.extract_tables()? On this file it returns 20-21 sparse columns with
several values merged into one cell ('576.75 605.85 95.20') and fragmented headers
(see logs/extraction_log.md). Instead we group words into visual rows by y-position and
accept a row only if: first token(s) = a known DisCo label AND every remaining token is
a pure number. Prose lines such as 'Abuja (5.78pp)' fail the second test and are rejected.

Output: data/interim/raw_<table>.csv  (wide, exactly as printed, values still strings)
"""
import pdfplumber, re, csv, json, datetime
RAW = "data/raw/2026_Q1-Report.pdf"
PAGE_OFFSET = 6          # printed page number = PDF page - 6 (checked: PDF p.37 prints '31')
LABELS = ["All DisCos", "Port Harcourt", "Abuja", "Benin", "Eko", "Enugu", "Ibadan",
          "Ikeja", "Jos", "Kaduna", "Kano", "PH", "Yola"]
NUM = re.compile(r"^[-\u2212]?\d{1,3}(,\d{3})*(\.\d+)?$|^[-\u2212]?\d+(\.\d+)?$")

SPECS = {   # table -> (pdf pages, expected n numeric values per row, column names)
 "T04": ([37], 6, ["q4_energy_offtake_mwh_h","q4_available_pcc_mwh_h","q4_offtake_performance_pct",
                   "q1_energy_offtake_mwh_h","q1_available_pcc_mwh_h","q1_offtake_performance_pct"]),
 "T05": ([38,39], 6, ["q4_energy_offtake_gwh","q4_energy_billed_gwh","q4_eae_pct",
                      "q1_energy_offtake_gwh","q1_energy_billed_gwh","q1_eae_pct"]),
 "T06": ([40], 6, ["q4_energy_received_nbn","q4_energy_billed_nbn","q4_billing_eff_pct",
                   "q1_energy_received_nbn","q1_energy_billed_nbn","q1_billing_eff_pct"]),
 "T07": ([41], 6, ["q4_billing_eff_pct","q4_eae_pct","q4_variance_pp",
                   "q1_billing_eff_pct","q1_eae_pct","q1_variance_pp"]),
 "T08": ([42], 6, ["q4_total_billings_nbn","q4_revenue_collected_nbn","q4_collection_eff_pct",
                   "q1_total_billings_nbn","q1_revenue_collected_nbn","q1_collection_eff_pct"]),
 "T09": ([45], 6, ["myto_target_pct","q4_atcc_pct","q1_atcc_pct",
                   "q4_atcc_variance_pp","q1_atcc_variance_pp","q1_revenue_loss_gain_pct"]),
}

def visual_rows(page, tol=3):
    words = page.extract_words(keep_blank_chars=False, use_text_flow=False)
    words.sort(key=lambda w: (round(w["top"]), w["x0"]))
    rows, cur, cur_top = [], [], None
    for w in words:
        if cur_top is None or abs(w["top"] - cur_top) <= tol:
            cur.append(w); cur_top = w["top"] if cur_top is None else cur_top
        else:
            rows.append(sorted(cur, key=lambda x: x["x0"])); cur, cur_top = [w], w["top"]
    if cur: rows.append(sorted(cur, key=lambda x: x["x0"]))
    return rows

def parse_row(tokens):
    text = " ".join(tokens)
    for lab in LABELS:
        if text.startswith(lab + " "):
            rest = text[len(lab):].split()
            if rest and all(NUM.match(t) for t in rest):
                return lab, rest
    return None

log = []
with pdfplumber.open(RAW) as pdf:
    for tname, (pages, n_expected, cols) in SPECS.items():
        out, seen = [], set()
        for pg in pages:
            for r in visual_rows(pdf.pages[pg-1]):
                parsed = parse_row([w["text"] for w in r])
                if not parsed: continue
                lab, vals = parsed
                if len(vals) != n_expected:
                    log.append(f"{tname} p{pg}: row '{lab}' has {len(vals)} numeric tokens "
                               f"(expected {n_expected}) -> kept for manual review: {vals}")
                    continue
                if lab in seen:
                    log.append(f"{tname} p{pg}: duplicate row '{lab}' ignored"); continue
                seen.add(lab)
                out.append(dict(table=tname, pdf_page=pg, printed_page=pg-PAGE_OFFSET,
                                disco_raw=lab, **dict(zip(cols, vals))))
        with open(f"data/interim/raw_{tname}.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
        log.append(f"{tname}: pages {pages} -> {len(out)} rows extracted")
        print(log[-1])
open("logs/02_extract_warnings.txt","w").write("\n".join(log)+"\n")
print("\nWarnings/notes:"); [print(" ", l) for l in log if "rows extracted" not in l]

# ---------------------------------------------------------------------------------------
# Table 9 summary block (below the 'All DisCos' row): multi-line labels + '-' placeholders.
# Values are assigned to columns by x-position; labels are fixed text because the printed
# labels wrap over 2-3 lines and cannot be reconstructed reliably from y-grouping.
# This is a documented semi-manual rule (see docs/CHANGELOG manual rules).
# ---------------------------------------------------------------------------------------
COLX = {"myto_target_pct": 212, "q4_atcc_pct": 268, "q1_atcc_pct": 324,
        "q4_atcc_variance_pp": 384, "q1_atcc_variance_pp": 434, "q1_revenue_loss_gain_pct": 503}
SUMMARY_ROWS = [("MYTO Level", "MYTO"), ("Total Technical, Commercial & Collection losses", "Total"),
                ("Technical & Commercial losses", "Technical"), ("Collection losses", "Collection")]
with pdfplumber.open(RAW) as pdf:
    p = pdf.pages[44]
    words = p.extract_words()
    y0 = [w["top"] for w in words if w["text"] == "Yola"][-1]
    y1 = [w["top"] for w in words if w["text"] == "2.3.6"][0]
    block = [w for w in words if y0 + 8 < w["top"] < y1 - 2]
    out = []
    for label, anchor in SUMMARY_ROWS:
        # anchor word = first word of the row's label; for 'Collection losses' take the LAST
        # 'Collection' (the first one is the 3rd wrapped line of the 'Total...' label)
        cands = [w for w in block if w["text"] == anchor and w["x0"] < 70]
        a = cands[-1] if anchor == "Collection" else cands[0]
        # a row's numbers sit on the anchor's line; for 'Total', numbers are on the anchor line too
        line = [w for w in block if abs(w["top"] - a["top"]) <= 3 and NUM.match(w["text"])]
        rec = dict(table="T09", pdf_page=45, printed_page=45 - PAGE_OFFSET, disco_raw=label,
                   **{k: "" for k in COLX})
        for w in line:
            col = min(COLX, key=lambda k: abs(COLX[k] - w["x0"]))
            if abs(COLX[col] - w["x0"]) < 25: rec[col] = w["text"]
        out.append(rec)
with open("data/interim/raw_T09_summary.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
print("\nT09 summary block:"); [print(" ", {k: v for k, v in r.items() if k not in ("table","pdf_page","printed_page")}) for r in out]
