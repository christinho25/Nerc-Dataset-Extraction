"""Step 1: page-by-page inventory of the raw PDF (audit trail)."""
import pdfplumber, csv, re
RAW = "data/raw/2026_Q1-Report.pdf"
OUT = "data/interim/page_inventory.csv"

rows = []
with pdfplumber.open(RAW) as pdf:
    for i, p in enumerate(pdf.pages, 1):
        txt = p.extract_text() or ""
        lines = [l.strip() for l in txt.splitlines() if l.strip()]
        n_lines = len(p.find_tables())
        n_text = len(p.find_tables({"vertical_strategy": "text", "horizontal_strategy": "text"}))
        caption = next((l for l in lines if re.match(r"^(Table|Figure)\s+\d+", l)), "")
        if len(txt) < 30 and len(p.images) > 0:
            method = "ocr_or_image_page"
        elif n_lines:
            method = "pdfplumber_lines"
        else:
            method = "prose_or_borderless"
        rows.append(dict(page=i, chars=len(txt), n_images=len(p.images),
                         n_tables_lines=n_lines, n_tables_text=n_text,
                         caption=caption[:110], first_line=(lines[0] if lines else "")[:80],
                         suggested_method=method))
with open(OUT, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys())
    w.writeheader(); w.writerows(rows)
print(len(rows), "pages inventoried ->", OUT)
