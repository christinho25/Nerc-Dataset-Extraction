"""Step 7: rebuild Figure 8 from the extracted data and place it beside the original (cropped from the PDF)."""
import subprocess, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.image as mpimg
RAW = "data/raw/2026_Q1-Report.pdf"
subprocess.run(["pdftoppm","-png","-r","170","-f","48","-l","48","-x","110","-y","165","-W","1130","-H","625",
                RAW,"figures/_orig_fig8"], check=True)
orig = mpimg.imread("figures/_orig_fig8-48.png")
f = pd.read_csv("data/processed/figure8_replication.csv")
x = range(len(f)); w = 0.38
fig, (a0, a1) = plt.subplots(1, 2, figsize=(17, 6.2), gridspec_kw={"width_ratios": [1, 1]})
a0.imshow(orig); a0.axis("off"); a0.set_title("Original: NERC Q1 2026 report, Figure 8 (PDF p.48)", fontsize=11)
b1 = a1.bar([i - w/2 for i in x], f.table10_dro_invoice, w, color="#4472C4", label="NBET Invoice (Table 10)")
b2 = a1.bar([i + w/2 for i in x], f.fig8_remittance_label, w, color="#ED7D31", label="NBET Remittance (Fig. 8 labels)")
for bars in (b1, b2):
    for r in bars: a1.text(r.get_x() + r.get_width()/2, r.get_height() + 0.6, f"{r.get_height():.2f}",
                           ha="center", va="bottom", fontsize=7, rotation=90)
a1.set_xticks(list(x)); a1.set_xticklabels([d.replace("Port Harcourt", "Port\nHarcourt") for d in f.disco], fontsize=8)
for i, (p, rc) in enumerate(zip(f.fig8_performance_printed_pct, f.recomputed_rounded)):
    a1.text(i, -9.5, f"{rc}%", ha="center", fontsize=8, color="#1b5e20" if p == rc else "red",
            bbox=dict(boxstyle="round,pad=0.25", fc="#dbe8f7", ec="none"))
a1.text(-0.9, -9.5, "Perf.\n(recomputed)", ha="right", va="center", fontsize=7)
a1.set_ylim(0, 66); a1.set_ylabel("₦ Billion"); a1.legend(loc="upper right", fontsize=8, frameon=False)
a1.spines[["top", "right"]].set_visible(False)
a1.set_title("Replica: rebuilt from extracted dataset", fontsize=11)
fig.text(0.5, 0.005, "Replica checks: 11/11 invoice bars equal Table 10; 11/11 performance % reproduced; "
         "Σ remittance = 312.48, Σ invoice = 331.40, aggregate 94.29% (all equal the report's quoted totals).",
         ha="center", fontsize=9)
plt.tight_layout(rect=(0, 0.04, 1, 1))
fig.savefig("figures/fig8_replication_side_by_side.png", dpi=130)
print("saved figures/fig8_replication_side_by_side.png")
