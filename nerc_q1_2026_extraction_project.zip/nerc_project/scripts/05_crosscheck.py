"""Step 5: independent cross-check of extracted figures against the original.
 (a) 100% automated: re-read the same pages with a different engine (poppler pdftotext -layout)
     and compare every numeric cell with the pdfplumber-based extraction.
 (b) Draw a seeded random sample (5 cells per table, 30 total) for visual comparison against
     rasterised page images -> docs/manual_verification.csv (observed values recorded by a human/reviewer).
"""
import subprocess, re, csv, random, pandas as pd
RAW = "data/raw/2026_Q1-Report.pdf"
NUM = re.compile(r"^[-\u2212]?[\d,]*\.?\d+$")
LABELS = ["All DisCos", "Port Harcourt", "Abuja", "Benin", "Eko", "Enugu", "Ibadan", "Ikeja", "Jos",
          "Kaduna", "Kano", "PH", "Yola"]
PAGES = {"T04": [37], "T05": [38, 39], "T06": [40], "T07": [41], "T08": [42], "T09": [45]}

def poppler_rows(pages):
    out = {}
    for pg in pages:
        txt = subprocess.run(["pdftotext", "-layout", "-f", str(pg), "-l", str(pg), RAW, "-"],
                             capture_output=True, text=True).stdout
        for line in txt.splitlines():
            line = line.strip()
            for lab in LABELS:
                if line.startswith(lab + " "):
                    rest = line[len(lab):].split()
                    if rest and all(NUM.match(t) for t in rest) and len(rest) == 6:
                        out[lab] = rest
                    break
    return out

mism, n_cmp = [], 0
for t, pages in PAGES.items():
    alt = poppler_rows(pages)
    raw = pd.read_csv(f"data/interim/raw_{t}.csv", dtype=str)
    cols = [c for c in raw.columns if c not in ("table", "pdf_page", "printed_page", "disco_raw")]
    for _, r in raw.iterrows():
        a = alt.get(r["disco_raw"])
        if a is None:
            mism.append((t, r["disco_raw"], "row not found by poppler", "")); continue
        for c, v1, v2 in zip(cols, [r[c] for c in cols], a):
            n_cmp += 1
            if v1 != v2: mism.append((t, r["disco_raw"], c, f"{v1} vs {v2}"))
print(f"(a) independent re-read: {n_cmp} cells compared, {len(mism)} mismatches")
for m in mism: print("   ", m)

# (b) seeded stratified sample for visual verification
d = pd.read_csv("data/processed/nerc_2026Q1_disco_long.csv")
rng = random.Random(42)
sample = []
for t, g in d.groupby("source_table"):
    idx = rng.sample(list(g.index), 5)
    sample.append(g.loc[idx])
s = pd.concat(sample)[["source_table", "pdf_page", "printed_page", "quarter", "disco", "metric", "value"]]
s = s.rename(columns={"value": "extracted_value"})
s["observed_in_pdf_image"] = ""; s["match"] = ""
s.to_csv("docs/manual_verification.csv", index=False)
print("\n(b) sample of", len(s), "cells ->docs/manual_verification.csv")
print(s[["source_table", "pdf_page", "quarter", "disco", "metric", "extracted_value"]].to_string(index=False))
