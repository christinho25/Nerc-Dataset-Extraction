"""Step 6: replicate published results.
 A. CHART: Figure 8 (DisCo remittance to NBET, p.48 PDF / printed p.42) rebuilt from
    - NBET invoice  : Table 10 (p.47), cross-checked against the invoice bar labels
    - NBET remittance: bar data labels read from the vector text of Figure 8 (rotated digits)
    and compared with the printed 'Performance' row, the prose percentages and quoted totals.
 B. CALCULATION: Table 9 'Revenue Loss/Gain (%)' column and the quoted revenue loss (N140.64bn),
    which the report does not give a formula for. Hypothesis (ours, not NERC's):
        expected revenue_i = received_i / (1+VAT) * (1 - MYTO target_i);  VAT=7.5% from 2026/Q1 (footnote 17)
        loss/gain_i (%)    = (collected_i - expected_i) / expected_i * 100
"""
import pdfplumber, re, subprocess, pandas as pd, numpy as np
from collections import defaultdict
RAW = "data/raw/2026_Q1-Report.pdf"
DISCOS = ["Abuja","Benin","Eko","Enugu","Ibadan","Ikeja","Jos","Kaduna","Kano","Port Harcourt","Yola"]
NUM = re.compile(r"^\d{1,3}(,\d{3})*\.\d+$")

# ---------------- A1. Table 10 (page 47) ----------------
t10 = {}
with pdfplumber.open(RAW) as pdf:
    p47 = pdf.pages[46]
    rows = defaultdict(list)
    for w in p47.extract_words(): rows[round(w["top"] / 3)].append(w)
    for k in sorted(rows):
        toks = [w["text"] for w in sorted(rows[k], key=lambda w: w["x0"])]
        txt = " ".join(toks)
        for lab in DISCOS + ["All DisCos"]:
            if txt.startswith(lab + " ") and all(NUM.match(t) for t in txt[len(lab):].split()):
                v = [float(t.replace(",", "")) for t in txt[len(lab):].split()]
                if len(v) == 2: t10[lab] = v
assert len(t10) == 12, t10.keys()

# ---------------- A2. Figure 8 data labels (page 48) ----------------
with pdfplumber.open(RAW) as pdf:
    p48 = pdf.pages[47]
    # bar data labels are the ROTATED digits (text matrix b-component != 0); axis ticks / % row are upright
    ch = [c for c in p48.chars if 85 < c["top"] < 320 and (c["text"].isdigit() or c["text"] == ".")
          and abs(c["matrix"][1]) > 1]
    groups = defaultdict(list)
    for c in ch: groups[round(c["x0"])].append(c)
    labels = []
    for x, cs in sorted(groups.items()):
        cs.sort(key=lambda c: -c["top"])                      # rotated 90deg CCW: read bottom -> top
        labels.append((x, "".join(c["text"] for c in cs)))
    # chart 'Performance' row (upright words on the same line as the word 'Performance')
    words = p48.extract_words()
    ptop = [w["top"] for w in words if w["text"] == "Performance" and w["top"] < 400][0]
    perf = sorted([w for w in words if abs(w["top"] - ptop) < 3 and re.fullmatch(r"\d+%", w["text"])],
                  key=lambda w: w["x0"])
    perf_printed = [int(w["text"][:-1]) for w in perf]
    prose = dict(re.findall(r"([A-Z][a-z]+) \((\d{2,3}\.\d+)%\)", p48.extract_text().split("Figure 8")[1].split("2.3.6.2")[0]))
assert len(labels) == 22 and len(perf_printed) == 11, (len(labels), len(perf_printed))
fig = pd.DataFrame({"disco": DISCOS,
                    "fig8_invoice_label": [float(labels[2*i][1]) for i in range(11)],
                    "fig8_remittance_label": [float(labels[2*i+1][1]) for i in range(11)],
                    "table10_dro_invoice": [t10[d][1] for d in DISCOS],
                    "fig8_performance_printed_pct": perf_printed})
fig["performance_recomputed_pct"] = (fig.fig8_remittance_label / fig.table10_dro_invoice * 100).clip(upper=100)
fig["recomputed_rounded"] = fig.performance_recomputed_pct.round(0).astype(int)
fig["prose_pct"] = [float(prose.get(d.split()[0], np.nan)) if d.split()[0] in prose else np.nan for d in DISCOS]
fig["raw_ratio_pct"] = fig.fig8_remittance_label / fig.table10_dro_invoice * 100
fig.to_csv("data/processed/figure8_replication.csv", index=False)

print("=== A. FIGURE 8 ===")
print("invoice bar labels == Table 10 DRO-adjusted invoice for all 11 DisCos:",
      bool((fig.fig8_invoice_label == fig.table10_dro_invoice).all()))
print("printed performance row == recomputed (rounded, capped at 100%):",
      bool((fig.fig8_performance_printed_pct == fig.recomputed_rounded).all()))
m = fig.dropna(subset=["prose_pct"])
print("prose % vs recomputed (max abs diff, pp):", round((m.prose_pct - m.raw_ratio_pct).abs().max(), 3),
      "for", list(m.disco))
si, sr = fig.fig8_invoice_label.sum(), fig.fig8_remittance_label.sum()
print(f"sum invoice {si:.2f} (Table 10 total {t10['All DisCos'][1]:.2f}; prose 331.40) | "
      f"sum remittance {sr:.2f} (prose 312.48) | aggregate performance {sr/si*100:.2f}% (prose 94.29%)")
print(fig[["disco","fig8_invoice_label","fig8_remittance_label","fig8_performance_printed_pct","recomputed_rounded","raw_ratio_pct","prose_pct"]].round(2).to_string(index=False))

# ---------------- B. Revenue loss/gain replication ----------------
d = pd.read_csv("data/processed/nerc_2026Q1_disco_long.csv")
def g(table, q, metric):
    x = d[(d.source_table == table) & (d.quarter == q) & (d.metric == metric)]
    return x.set_index("disco").value
rec, col, tgt = g("Table 6","2026/Q1","energy_received_nbn"), g("Table 8","2026/Q1","revenue_collected_nbn"), g("Table 9","2026/Q1","myto_target_pct")
pub = g("Table 9","2026/Q1","revenue_loss_gain_pct")
VAT = 0.075
b = pd.DataFrame({"received": rec, "collected": col, "target": tgt}).loc[DISCOS]
b["expected"] = b.received / (1 + VAT) * (1 - b.target / 100)
b["recomputed_pct"] = (b.collected - b.expected) / b.expected * 100
b["published_pct"] = pub.reindex(DISCOS)
b["diff_pp"] = b.recomputed_pct - b.published_pct
tot_rec, tot_col, tot_tgt = rec["All DisCos"], col["All DisCos"], 16.92
exp_tot = tot_rec / (1 + VAT) * (1 - tot_tgt / 100)
loss_q1 = exp_tot - tot_col
# 2025/Q4 (no VAT adjustment before 2026/Q1; aggregate target implied by text: ATC&C 34.90 - variance 14.36)
rec4, col4 = g("Table 6","2025/Q4","energy_received_nbn")["All DisCos"], g("Table 8","2025/Q4","revenue_collected_nbn")["All DisCos"]
tgt4 = 34.90 - 14.36
loss_q4 = rec4 * (1 - tgt4/100) - col4
print("\n=== B. REVENUE LOSS/GAIN ===")
print(b.round(2).to_string())
print(f"\nPer-DisCo: max |diff| = {b.diff_pp.abs().max():.3f} pp ; all within 0.06pp: {bool((b.diff_pp.abs() <= 0.06).all())}")
print(f"All DisCos 2026/Q1: expected {exp_tot:.2f}, collected {tot_col:.2f}, loss {loss_q1:.2f} bn (published 140.64); "
      f"as % of expected = {-loss_q1/exp_tot*100:.2f}% (published Table 9: -19.05%; footnote 19: '19%')")
print(f"All DisCos 2025/Q4 (no VAT adj.; implied target {tgt4:.2f}%): loss {loss_q4:.2f} bn (published 139.19)")
b.assign(vat_rate=VAT).to_csv("data/processed/revenue_loss_replication.csv")
pd.DataFrame([
  dict(item="Revenue loss 2026/Q1 (NGN bn)", published=140.64, recomputed=round(loss_q1,2), source="p.38 text"),
  dict(item="Revenue loss 2025/Q4 (NGN bn)", published=139.19, recomputed=round(loss_q4,2), source="p.38 text"),
]).to_csv("data/processed/revenue_loss_totals.csv", index=False)
