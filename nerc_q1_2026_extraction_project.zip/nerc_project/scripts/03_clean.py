"""Step 3: tidy long-format dataset from the raw wide extracts.
Rules (all logged in docs/CHANGELOG.md):
 R1 DisCo names standardised: 'PH' -> 'Port Harcourt'. 'All DisCos' kept, flagged is_total.
 R2 Numbers: thousands commas removed, unicode minus -> '-', cast to float. '-' placeholders -> not emitted.
 R3 Quarter: column prefix q4_ -> 2025/Q4, q1_ -> 2026/Q1. MYTO target is a 2026 annual parameter,
    stored against 2026/Q1 with note.
 R4 Units derived from column suffix.
"""
import csv, glob, re
NAME_MAP = {"PH": "Port Harcourt"}
UNIT = [("_mwh_h", "MWh/h"), ("_gwh", "GWh"), ("_nbn", "NGN billion"), ("_pct", "%"), ("_pp", "pp")]
QMAP = {"q4_": "2025/Q4", "q1_": "2026/Q1"}
SUMMARY_METRIC = {"MYTO Level": ("All DisCos", "myto_target_pct"),
    "Total Technical, Commercial & Collection losses": ("All DisCos", "atcc_total_pct"),
    "Technical & Commercial losses": ("All DisCos", "atcc_technical_commercial_pct"),
    "Collection losses": ("All DisCos", "atcc_collection_pct")}
PRIMARY = {"eae_pct": "Table 5", "billing_eff_pct": "Table 6"}   # metrics that appear in >1 table

def num(s):
    s = s.replace("\u2212", "-").replace(",", "").strip()
    return float(s)

def unit_of(col):
    for suf, u in UNIT:
        if col.endswith(suf): return u
    raise ValueError(col)

rows = []
def emit(r, disco, col, val, summary_label=None):
    quarter, metric = None, col
    for pre, q in QMAP.items():
        if col.startswith(pre): quarter, metric = q, col[len(pre):]
    note = ""
    if quarter is None:
        quarter, note = "2026/Q1", "2026 annual MYTO parameter"
    rows.append(dict(quarter=quarter, disco=disco, is_total=int(disco == "All DisCos"),
                     metric=metric, value=num(val), unit=unit_of(col),
                     source_table=re.sub(r"^T0?(\d+)$", r"Table \1", r["table"]),
                     pdf_page=r["pdf_page"], printed_page=r["printed_page"],
                     source_label=r["disco_raw"], note=note))

for fn in sorted(glob.glob("data/interim/raw_T0?.csv")):
    for r in csv.DictReader(open(fn)):
        disco = NAME_MAP.get(r["disco_raw"], r["disco_raw"])
        for col, val in r.items():
            if col in ("table", "pdf_page", "printed_page", "disco_raw") or val == "": continue
            emit(r, disco, col, val)

for r in csv.DictReader(open("data/interim/raw_T09_summary.csv")):
    disco, base = SUMMARY_METRIC[r["disco_raw"]]
    for col, val in r.items():
        if col in ("table", "pdf_page", "printed_page", "disco_raw") or val == "": continue
        if r["disco_raw"] == "MYTO Level":
            emit(r, disco, col, val)
        elif col.startswith("q") and col.endswith("_atcc_pct"):
            emit(r, disco, col.replace("atcc", base.replace("_pct", "")), val)
        elif col == "q1_revenue_loss_gain_pct":
            emit(r, disco, col, val)

# primary flag for metrics that appear in more than one table
for r in rows:
    r["is_primary"] = int(PRIMARY[r["metric"]] == r["source_table"]) if r["metric"] in PRIMARY else 1

rows.sort(key=lambda r: (int(r["source_table"].split()[1]), r["quarter"], r["disco"], r["metric"]))
cols = ["quarter","disco","is_total","metric","value","unit","source_table","pdf_page",
        "printed_page","source_label","is_primary","note"]
with open("data/processed/nerc_2026Q1_disco_long.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
print(len(rows), "rows written -> data/processed/nerc_2026Q1_disco_long.csv")
