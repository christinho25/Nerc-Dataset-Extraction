"""Step 4: internal validation of the extracted dataset (no reference to the PDF image).
Rounding-aware: published inputs/outputs are rounded to 2 dp (half-unit 0.005), so a recomputed
ratio is compared against the interval it could take given input rounding."""
import pandas as pd, csv
d = pd.read_csv("data/processed/nerc_2026Q1_disco_long.csv")
H = 0.005
res = []
def log(check, key, status, detail=""):
    res.append(dict(check=check, key=key, status=status, detail=detail))

def get(table, q, metric):
    x = d[(d.source_table == table) & (d.quarter == q) & (d.metric == metric)]
    return x.set_index("disco").value

DISCOS = ["Abuja","Benin","Eko","Enugu","Ibadan","Ikeja","Jos","Kaduna","Kano","Port Harcourt","Yola"]
QS = ["2025/Q4", "2026/Q1"]

# A. completeness ---------------------------------------------------------------------
for t in ["Table 4","Table 5","Table 6","Table 7","Table 8"]:
    for q in QS:
        sub = d[(d.source_table == t) & (d.quarter == q)]
        ok = set(sub.disco) == set(DISCOS) | {"All DisCos"} and sub.groupby("disco").size().nunique() == 1
        log("A.completeness", f"{t} {q}", "PASS" if ok else "FAIL", f"{sub.disco.nunique()} DisCos")
sub = d[(d.source_table == "Table 9") & (d.disco != "All DisCos")]
log("A.completeness", "Table 9 DisCos", "PASS" if sub.disco.nunique() == 11 else "FAIL", f"{sub.disco.nunique()} DisCos")

# B. ratio recomputation (interval arithmetic) -----------------------------------------------
def ratio_check(name, table, q, num_m, den_m, pct_m, num_table=None):
    n, dn, p = get(table, q, num_m), get(table, q, den_m), get(table, q, pct_m)
    for disco in n.index:
        lo = (n[disco]-H)/(dn[disco]+H)*100 - H; hi = (n[disco]+H)/(dn[disco]-H)*100 + H
        ok = lo <= p[disco] <= hi
        log(name, f"{q} {disco}", "PASS" if ok else "FAIL",
            f"reported {p[disco]:.2f}; recomputed {n[disco]/dn[disco]*100:.3f} (allowed {lo:.3f}-{hi:.3f})")
for q in QS:
    p = "q4_" if q == "2025/Q4" else "q1_"
    ratio_check("B1.offtake_perf=offtake/PCC", "Table 4", q, "energy_offtake_mwh_h", "available_pcc_mwh_h", "offtake_performance_pct")
    ratio_check("B2.EAE=billed/offtake", "Table 5", q, "energy_billed_gwh", "energy_offtake_gwh", "eae_pct")
    ratio_check("B3.BE=billed/received", "Table 6", q, "energy_billed_nbn", "energy_received_nbn", "billing_eff_pct")
    ratio_check("B4.CE=collected/billings", "Table 8", q, "revenue_collected_nbn", "total_billings_nbn", "collection_eff_pct")
    # B5 Table 7 variance = BE - EAE (published to 2dp from unrounded values: allow 0.015)
    be, ea, vr = get("Table 7", q, "billing_eff_pct"), get("Table 7", q, "eae_pct"), get("Table 7", q, "variance_pp")
    for disco in be.index:
        diff = abs((be[disco]-ea[disco]) - vr[disco])
        log("B5.variance=BE-EAE (within Table 7)", f"{q} {disco}", "PASS" if diff <= 0.015 else "FAIL",
            f"BE-EAE={be[disco]-ea[disco]:.2f}; reported {vr[disco]:.2f}; diff {diff:.3f}")
# B6 ATC&C = 100 - BE*CE/100 ; B7 variance = target - atcc
tgt = get("Table 9", "2026/Q1", "myto_target_pct")
for q in QS:
    at = get("Table 9", q, "atcc_pct"); be = get("Table 6", q, "billing_eff_pct"); ce = get("Table 8", q, "collection_eff_pct")
    var = get("Table 9", q, "atcc_variance_pp")
    for disco in at.index:
        calc = 100 - be[disco]*ce[disco]/100
        log("B6.ATC&C=100-BE*CE", f"{q} {disco}", "PASS" if abs(calc-at[disco]) <= 0.03 else "FAIL",
            f"reported {at[disco]:.2f}; recomputed {calc:.2f}")
        if q == "2026/Q1":
            log("B7.ATC&C variance=target-ATC&C", f"{q} {disco}",
                "PASS" if abs((tgt[disco]-at[disco]) - var[disco]) <= 0.015 else "FAIL",
                f"target-ATC&C={tgt[disco]-at[disco]:.2f}; reported {var[disco]:.2f}")
        else:   # 2025/Q4 variance was measured against the 2025 target (not published here)
            log("B7i.implied 2025 MYTO target (info)", f"{q} {disco}", "INFO",
                f"implied target = ATC&C - variance = {at[disco]-var[disco]:.2f} (cannot be verified from this report)")

# C. sums of 11 DisCos vs 'All DisCos' ---------------------------------------------------
for t, mets in [("Table 4", ["energy_offtake_mwh_h","available_pcc_mwh_h"]),
                ("Table 5", ["energy_offtake_gwh","energy_billed_gwh"]),
                ("Table 6", ["energy_received_nbn","energy_billed_nbn"]),
                ("Table 8", ["total_billings_nbn","revenue_collected_nbn"])]:
    for q in QS:
        for m in mets:
            s = get(t, q, m); tot = s["All DisCos"]; ssum = s.drop("All DisCos").sum()
            log("C.sum_of_DisCos=total", f"{t} {q} {m}", "PASS" if abs(ssum-tot) <= 12*H else "FAIL",
                f"sum {ssum:.2f} vs total {tot:.2f} (diff {ssum-tot:+.2f})")

# D. cross-table consistency ---------------------------------------------------------------
for q in QS:
    for disco in DISCOS + ["All DisCos"]:
        a, b = get("Table 6", q, "energy_billed_nbn")[disco], get("Table 8", q, "total_billings_nbn")[disco]
        log("D1.T6 billed(NGN) == T8 billings", f"{q} {disco}", "PASS" if abs(a-b) < 1e-9 else "FAIL", f"{a} vs {b}")
        for m, t1, t2 in [("billing_eff_pct","Table 6","Table 7"), ("eae_pct","Table 5","Table 7")]:
            a, b = get(t1, q, m)[disco], get(t2, q, m)[disco]
            log(f"D2.{m} {t1} == {t2}", f"{q} {disco}", "PASS" if abs(a-b) < 1e-9 else "FAIL", f"{a} vs {b}")
# D3 energy: MWh/h x hours in quarter ~ GWh (Q4-2025 = 92d, Q1-2026 = 90d)
for q, hrs in [("2025/Q4", 92*24), ("2026/Q1", 90*24)]:
    a, b = get("Table 4", q, "energy_offtake_mwh_h"), get("Table 5", q, "energy_offtake_gwh")
    for disco in DISCOS + ["All DisCos"]:
        calc = a[disco]*hrs/1000
        log("D3.T4 MWh/h x hours ~= T5 GWh", f"{q} {disco}", "PASS" if abs(calc-b[disco])/b[disco] < 0.005 else "FAIL",
            f"{calc:.1f} vs {b[disco]:.1f} ({(calc/b[disco]-1)*100:+.2f}%)")

# D4. Footnote 'Ibadan 2025/Q4 energy billed has been revised' -> test numerically.
# Table 7 EAE for Ibadan implies the PRE-revision billed energy; swap it into the total.
off = get("Table 5", "2025/Q4", "energy_offtake_gwh"); bil = get("Table 5", "2025/Q4", "energy_billed_gwh")
e7 = get("Table 7", "2025/Q4", "eae_pct")
pre_billed = e7["Ibadan"]/100*off["Ibadan"]
pre_total_eae = (bil["All DisCos"] - bil["Ibadan"] + pre_billed)/off["All DisCos"]*100
log("D4.footnote explains T5 vs T7 gap", "2025/Q4 All DisCos",
    "PASS" if abs(pre_total_eae - e7["All DisCos"]) <= 0.02 else "FAIL",
    f"implied pre-revision Ibadan billed {pre_billed:.1f} GWh (revised {bil['Ibadan']:.2f}); "
    f"total EAE with pre-revision value = {pre_total_eae:.2f}% vs Table 7 {e7['All DisCos']:.2f}%")

# Failures visually confirmed against rasterised PDF pages (figures/verify/*.png): source issue, not extraction error
KNOWN = {
 ("C.sum_of_DisCos=total", "Table 6 2025/Q4 energy_received_nbn"): "Printed total 969.19 confirmed on p.40 image; DisCo rows sum to 970.21",
 ("C.sum_of_DisCos=total", "Table 6 2026/Q1 energy_received_nbn"): "Printed total 955.19 confirmed on p.40 image; DisCo rows sum to 955.73",
 ("C.sum_of_DisCos=total", "Table 8 2025/Q4 revenue_collected_nbn"): "Printed total 630.93 confirmed on p.42 image; DisCo rows sum to 630.85",
 ("D2.eae_pct Table 5 == Table 7", "2025/Q4 Ibadan"): "87.40 printed in Table 7 (p.41 image); Table 5 shows revised 88.76; footnote p.39 (see D4)",
 ("D2.eae_pct Table 5 == Table 7", "2025/Q4 All DisCos"): "82.77 printed in Table 7 (p.41 image); Table 5 shows 82.94; footnote p.39 (see D4)",
}
for r in res:
    if r["status"] == "FAIL" and (r["check"], r["key"]) in KNOWN:
        r["status"] = "SOURCE_DISCREPANCY"
        r["detail"] += " | VERIFIED IN SOURCE: " + KNOWN[(r["check"], r["key"])]

pd.DataFrame(res).to_csv("data/processed/validation_log.csv", index=False)
r = pd.DataFrame(res)
print(r.groupby(["check","status"]).size().unstack(fill_value=0).to_string())
print("\nSTATUS COUNTS:", r.status.value_counts().to_dict())
print("\nFAILURES:"); print(r[r.status=="FAIL"][["check","key","detail"]].to_string(index=False))
