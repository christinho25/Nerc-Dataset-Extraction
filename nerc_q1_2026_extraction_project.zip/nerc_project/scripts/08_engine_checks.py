"""Step 8: (a) test whether OCR is needed; (b) third-engine check of Table 4 with Camelot (stream)."""
import pandas as pd, subprocess, pytesseract, camelot, re
inv = pd.read_csv("data/interim/page_inventory.csv")
img = inv[inv.suggested_method == "ocr_or_image_page"]
print("(a) image-only pages (<30 text chars):", list(img.page))
for pg in img.page:
    subprocess.run(["pdftoppm","-png","-r","150","-f",str(pg),"-l",str(pg),"data/raw/2026_Q1-Report.pdf",f"data/interim/ocr_p{pg}"],check=True)
    import glob; f = glob.glob(f"data/interim/ocr_p{pg}-*.png")[0]
    txt = pytesseract.image_to_string(f).strip().replace("\n", " | ")
    print(f"    OCR p{pg}: {txt[:160]!r}")
# (b) Camelot stream on Table 4 (p.37)
t = camelot.read_pdf("data/raw/2026_Q1-Report.pdf", pages="37", flavor="stream")
print(f"\n(b) Camelot stream found {t.n} table(s) on p.37; shape {t[0].df.shape}")
df = t[0].df
num = re.compile(r"^-?[\d,]+\.\d+$")
cam = {}
for _, r in df.iterrows():
    cells = [c.strip() for c in r.tolist() if c.strip()]
    vals = [c for c in cells if num.match(c)]
    if cells and len(vals) == 6: cam[cells[0]] = vals
ref = pd.read_csv("data/interim/raw_T04.csv", dtype=str)
cols = [c for c in ref.columns if c.startswith("q")]
bad = 0; n = 0
for _, r in ref.iterrows():
    c = cam.get(r["disco_raw"])
    if not c: print("    Camelot missed row", r["disco_raw"]); continue
    for col, v in zip(cols, c):
        n += 1; bad += (r[col] != v)
print(f"    Camelot vs pdfplumber on Table 4: {n} cells compared, {bad} mismatches ({len(cam)}/12 rows parsed by Camelot)")
