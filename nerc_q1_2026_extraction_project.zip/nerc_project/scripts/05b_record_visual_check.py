"""Step 5b: record the values read by eye from rasterised page images (figures/verify/*.png)
for the 30 sampled cells in docs/manual_verification.csv, in sampled order. Match is computed, not asserted."""
import pandas as pd
OBSERVED = [  # transcribed from the page images, in the order of the sample file
 "99.38","3,926.15","70.38","284.12","199.89",          # Table 4 (p.37)
 "956.58","511.00","79.43","1,061.56","84.95",           # Table 5 (p.38-39)
 "795.06","82.03","130.89","94.09","53.02",              # Table 6 (p.40)
 "84.18","82.03","-20.29","81.69","59.14",               # Table 7 (p.41)
 "77.82","29.55","58.41","13.23","83.11",                # Table 8 (p.42)
 "-23.39","58.00","-24.63","-22.48","44.27"]             # Table 9 (p.45)
s = pd.read_csv("docs/manual_verification.csv")
assert len(s) == len(OBSERVED) == 30
s["observed_in_pdf_image"] = OBSERVED
s["match"] = [abs(float(o.replace(",", "")) - e) < 1e-9 for o, e in zip(OBSERVED, s.extracted_value)]
s.to_csv("docs/manual_verification.csv", index=False)
print(f"visual sample: {s.match.sum()}/{len(s)} cells match the original page images")
