# Source record

| Field | Value |
|---|---|
| Document | NERC First Quarter 2026 Quarterly Report (Nigerian Electricity Regulatory Commission) |
| Source URL | https://nerc.gov.ng/wp-content/uploads/2026/07/2026_Q1-Report.pdf |
| Local file | `data/raw/2026_Q1-Report.pdf` (read-only, never modified) |
| Retrieved | Supplied by the project owner (uploaded) on 2026-10-04; URL located via NERC website |
| SHA-256 | `1be8a56e42dce098e8de313ce71af9129ddc52517755668b7afd9b115be62f86` |
| Size / pages | 3,895,395 bytes / 94 pages (A4) |
| PDF metadata | Created 2026-07-01 with Microsoft Word for Microsoft 365; PDF 1.7; not encrypted; no attachments |
| Text layer | Yes (embedded fonts). Only p.1 (cover) and p.94 (back cover) are image-only; neither holds data |
| Page numbering | Printed page number = PDF page - 6 (e.g. PDF p.37 prints "31"). Both are stored on every row |

Verify integrity any time with: `sha256sum -c data/raw/SHA256SUMS.txt`
