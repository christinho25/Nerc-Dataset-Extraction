# Change log, manual rules and source issues (audit trail)

The raw PDF is never edited. Everything below is applied in code, except where marked **manual**.

## Cleaning / extraction rules
| ID | Rule | Where |
|---|---|---|
| R1 | `PH` (Table 4) standardised to `Port Harcourt` (used in Tables 5-9) | 03_clean.py |
| R2 | Thousands commas removed; unicode minus normalised; cast to float. `-` placeholders in Table 9 summary block not emitted | 03_clean.py |
| R3 | `q4_`->2025/Q4, `q1_`->2026/Q1; MYTO target stored against 2026/Q1 | 03_clean.py |
| R4 | Table 5 spans PDF pp.38-39: rows concatenated, duplicates ignored | 02_extract.py |
| R5 | Rows accepted only if label is a known DisCo AND all remaining tokens are pure numbers (rejects prose such as "Abuja (5.78pp)") | 02_extract.py |
| M1 (**manual**) | Table 9 summary block (All-DisCos rows): printed labels wrap over 2-3 lines, so labels are fixed text and values are assigned by x-position | 02_extract.py |
| M2 (**manual**) | Printed page = PDF page - 6, read off the page footer | 02_extract.py |
| M3 (**manual**) | Figure 8 bar labels are rotated text; read bottom-to-top and paired invoice/remittance by x-order. Pairing validated: invoice labels equal Table 10 for 11/11 DisCos | 06_replicate.py |

## Why `pdfplumber.extract_tables()` was not used for the data
Default settings returned 20-21 sparse columns, merged several values into one cell (e.g. `'576.75 605.85 95.20'`) and fragmented the header text across rows. A word-position row parser (R5) was used instead and then cross-checked with two other engines (poppler `pdftotext`, Camelot).

## Source issues found (reproduced faithfully, not "fixed")
| ID | Issue | Evidence |
|---|---|---|
| S1 | DisCo rows do not sum to the printed "All DisCos" total: Table 6 energy received (2025/Q4: 970.21 vs 969.19; 2026/Q1: 955.73 vs 955.19) and Table 8 revenue collected 2025/Q4 (630.85 vs 630.93) | Printed totals confirmed on page images. Totals are internally consistent with their own efficiencies |
| S2 | 2025/Q4 energy accounting efficiency differs between Table 5 (Ibadan 88.76, All 82.94) and Table 7 (87.40, 82.77). Footnote on PDF p.39 says Ibadan's 2025/Q4 billed energy was revised | Test D4: substituting the pre-revision Ibadan value implied by Table 7 into the Table 5 total gives 82.77%, which matches Table 7 exactly |

## Development defects caught by the checks (all fixed; recorded for transparency)
1. Table-name label was mangled ("Table able 4"): caught by the sanity summary after 03_clean.
2. `is_primary` flag was 0 for every row because of an id mismatch (`T05` vs `Table 5`): caught by the groupby check.
3. Validation check B7 wrongly tested 2025/Q4 variances against the 2026 target. The Q4 variance uses a 2025 target that this report does not publish. B7 now tests 2026/Q1 only; the Q4 implied target is logged as INFO.

## Inferences (not stated in the report)
- Revenue loss/gain formula (`expected = received/1.075 x (1 - target)`, `loss% = (collected - expected)/expected`) is **our hypothesis**. It reproduces all 11 published Table 9 values within 0.014pp and the quoted aggregate losses, but NERC does not publish the formula. 7.5% VAT follows footnote 17 (p.33).
- 2025/Q4 aggregate MYTO target of 20.54% = ATC&C 34.90 - variance 14.36 (both quoted on p.44).
