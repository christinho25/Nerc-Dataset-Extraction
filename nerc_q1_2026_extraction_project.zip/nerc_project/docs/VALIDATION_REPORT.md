# Validation report

## 1. Internal consistency (`04_validate.py`, `data/processed/validation_log.csv`)
Rounding-aware: the report rounds to 2 dp, so each recomputed ratio is compared with the interval it can take given input rounding.

| Check | Result |
|---|---|
| A. Completeness (11 DisCos + total in every table/quarter) | 11/11 pass |
| B1-B4. Published % recomputed from components (offtake perf., EAE, BE, CE) | 96/96 pass |
| B5. Table 7 variance = BE - EAE | 24/24 pass |
| B6. ATC&C = 100 - BE x CE (per DisCo, both quarters) | 22/22 pass |
| B7. 2026/Q1 ATC&C variance = target - ATC&C | 11/11 pass |
| C. Sum of 11 DisCos = All DisCos | 13/16 pass, 3 source discrepancies (S1) |
| D1. Table 6 billed (NGN) = Table 8 billings | 24/24 pass |
| D2. BE (T6 vs T7) and EAE (T5 vs T7) agree | 46/48 pass, 2 source discrepancies (S2) |
| D3. Table 4 MWh/h x hours in quarter ~ Table 5 GWh (within 0.5%) | 24/24 pass |
| D4. Footnote explanation of S2 reproduced numerically | pass |
Totals: 272 pass, 5 source discrepancy (verified on page images), 11 info, **0 unexplained failures**.

## 2. Cross-check against the original
| Method | Coverage | Result |
|---|---|---|
| Second engine, poppler `pdftotext -layout` | 426 of 426 table cells (Tables 4-9 DisCo rows) | 0 mismatches |
| Third engine, Camelot (stream) | Table 4, 72 cells | 0 mismatches |
| Visual comparison with rasterised page images | Seeded random sample, 5 cells x 6 tables = 30 (`docs/manual_verification.csv`); images in `figures/verify/` | 30/30 match |
| OCR (Tesseract 5.3.4) | Pages 1 and 94, the only image-only pages | No data on either; OCR not needed for data extraction |

Reading the numbers: the three text engines all read the same embedded text layer, so they guard against parsing errors but not against a wrong text layer. The visual sample guards against that. 0/30 visual errors means the true cell error rate is below about 9.5% at 95% confidence (rule of three); 0/426 on the second engine bounds parsing errors below about 0.7%. A larger visual sample would tighten the first bound.

## 3. Replication (`06_replicate.py`, `07_make_chart.py`)
**Chart: Figure 8** (remittance to NBET). Rebuilt from Table 10 plus the chart's own data labels: 11/11 invoice bars equal Table 10; 11/11 printed performance percentages reproduced; prose percentages agree within 0.028pp; sum of remittance 312.48, sum of invoice 331.40, aggregate 94.29%, all equal to the report's quoted totals. See `figures/fig8_replication_side_by_side.png`.

**Calculation: Table 9 "Revenue Loss/Gain (%)"** (formula undocumented in report). Reproduced for all 11 DisCos within 0.014pp; aggregate loss 140.65bn vs 140.64bn published (2026/Q1) and 139.19bn vs 139.19bn (2025/Q4). Treat the formula as an inference (see CHANGELOG).
