# Data dictionary: `data/processed/nerc_2026Q1_disco_long.csv` (434 rows)

One row per published number (DisCo x quarter x metric x source table).

| Column | Meaning |
|---|---|
| quarter | `2025/Q4` or `2026/Q1`. The MYTO target and revenue loss/gain are 2026 parameters, stored against `2026/Q1` |
| disco | Standardised name. 11 DisCos + `All DisCos` (report's own aggregate) |
| is_total | 1 for the `All DisCos` aggregate row |
| metric | See table below |
| value | Number as printed (thousands separators removed) |
| unit | MWh/h, GWh, NGN billion, %, pp (percentage points) |
| source_table | Table in the report the value was read from |
| pdf_page / printed_page | Page in the PDF file / page number printed on the page |
| source_label | Row label exactly as printed (e.g. `PH` in Table 4) |
| is_primary | 0 for the duplicate copy of EAE / billing efficiency in Table 7 (primary: Table 5 / Table 6) |
| note | Free text |

| metric | Definition (report equation) | Tables |
|---|---|---|
| energy_offtake_mwh_h, available_pcc_mwh_h, offtake_performance_pct | Offtake / available at PCC x 100 | 4 |
| energy_offtake_gwh, energy_billed_gwh, eae_pct | Energy accounting efficiency = billed / offtake x 100 (eq. 7) | 5, 7 |
| energy_received_nbn, energy_billed_nbn, billing_eff_pct | Billing efficiency = naira billed / naira value of energy received x 100 (eq. 8) | 6, 7 |
| variance_pp | BE - EAE | 7 |
| total_billings_nbn, revenue_collected_nbn, collection_eff_pct | Collection efficiency = collected / billed x 100 (eq. 9) | 8 |
| myto_target_pct, atcc_pct, atcc_variance_pp | ATC&C loss = [1 - BE x CE] x 100 (eq. 10); variance = target - actual | 9 |
| revenue_loss_gain_pct | Published revenue loss/gain (formula not stated in the report; see `06_replicate.py`) | 9 |
| atcc_total_pct, atcc_technical_commercial_pct, atcc_collection_pct | Aggregate ATC&C, (100 - BE) and (100 - CE) for All DisCos | 9 |

NGN billion is written `nbn` in raw column names. Note: 2025/Q4 values are shown as presented in *this* report, which revises some earlier figures (see CHANGELOG, source issue S2).
